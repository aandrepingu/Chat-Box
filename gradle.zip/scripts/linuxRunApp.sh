#!/usr/bin/env bash

cd ..

./gradlew run
