#!/usr/bin/env bash

cd ..

./gradlew javadoc-better