#!/usr/bin/env bash

cd ..

./gradlew bootRun
